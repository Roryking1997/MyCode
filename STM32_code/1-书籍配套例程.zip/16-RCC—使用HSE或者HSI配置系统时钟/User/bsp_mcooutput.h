#ifndef __MCOOUTPUT_H
#define	__MCOOUTPUT_H


#include "stm32f10x.h"

void MCO_GPIO_Config(void);


#endif /* __MCOOUTPUT */
